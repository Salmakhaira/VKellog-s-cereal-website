document.addEventListener("DOMContentLoaded", function() {
    var form = document.querySelector("form");
    form.addEventListener("submit", function(event) {
        var valid = true;

        var firstName = document.getElementById("first-name");
        var lastName = document.getElementById("last-name");
        var email = document.getElementById("email");
        var phone = document.getElementById("phone");
        var inquiry = document.getElementById("inquiry");

        //Validation
        if (firstName.value.trim() === "") {
            valid = false;
            alert("First name is required");
        }

        if (lastName.value.trim() === "") {
            valid = false;
            alert("Last name is required");
        }

        if (email.value.trim() === "") {
            valid = false;
            alert("Email is required");
        }

        if (phone.value.trim() === "") {
            valid = false;
            alert("Phone number is required");
        }

        if (inquiry.value.trim() === "") {
            valid = false;
            alert("Please specify the nature of your inquiry");
        }

        if (!valid) {
            event.preventDefault();
        }
    });
});


